<?php

class CartController extends Controller {
    
    public function index() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $cart = $_SESSION['cart'] ?? [];
        
        // --- CẬP NHẬT MỚI: Làm mới tồn kho từ DB (Sửa lỗi Unknown column 'quantity') ---
        $productModel = $this->model('Product');
        $baseModel = $this->model('Model'); 

        foreach ($cart as $key => &$item) {
            $currentStock = 0;
            
            if (isset($item['variant_id']) && $item['variant_id'] > 0) {
                // SỬA LỖI: Dùng SELECT * để tránh lỗi "Unknown column" nếu cột quantity không tồn tại
                // Sau đó xử lý kiểm tra tên cột ở phía PHP
                $variant = $baseModel->query("SELECT * FROM product_variants WHERE id = ?", [$item['variant_id']])->fetch();
                if ($variant) {
                    // Ưu tiên 'stock', dự phòng 'quantity' hoặc 'soluong'
                    $currentStock = $variant['stock'] ?? $variant['quantity'] ?? $variant['soluong'] ?? 0;
                }
            } else {
                // Với sản phẩm thường
                $prod = $productModel->show($item['id']);
                if ($prod) {
                    $currentStock = $prod['stock'] ?? $prod['quantity'] ?? $prod['soluong'] ?? 0;
                }
            }
            
            // Cập nhật lại số tồn kho vào session
            $item['stock'] = (int)$currentStock;
        }
        unset($item); // Hủy tham chiếu
        
        $_SESSION['cart'] = $cart;
        // -------------------------------------------------------------------

        $subtotal = 0;
        foreach ($cart as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }

        $discount = 0;
        $coupon = $_SESSION['applied_coupon'] ?? null;
        if ($coupon) {
            $discount = ($coupon['type'] === 'percent') ? ($subtotal * $coupon['value'] / 100) : $coupon['value'];
        }
        if ($discount > $subtotal) $discount = $subtotal;
        $total = $subtotal - $discount;

        $this->view('user.cart.index', [
            'title' => 'Giỏ hàng - MD',
            'cart' => $cart,
            'subtotal' => $subtotal,
            'discount' => $discount,
            'coupon' => $coupon,
            'total' => $total
        ]);
    }

    public function add($id, $variantId = null) {
        if (session_status() === PHP_SESSION_NONE) session_start();

        $productModel = $this->model('Product');
        $product = $productModel->show($id);

        if (!$product) {
            $this->redirect('product/index');
            return;
        }

        $cartKey = "p_" . $id; 
        $name = $product['name'];
        $price = $product['price'];
        $image = $product['image'];
        
        // Lấy tồn kho: ưu tiên stock
        $stock = $product['stock'] ?? $product['quantity'] ?? 0; 
        $attributes = ""; 

        if ($variantId && $variantId !== 'undefined' && $variantId > 0) {
            $variant = $this->model('Model')->query(
                "SELECT v.*, c.name as color_name, s.name as size_name 
                 FROM product_variants v 
                 LEFT JOIN colors c ON v.color_id = c.id 
                 LEFT JOIN sizes s ON v.size_id = s.id 
                 WHERE v.id = ? AND v.product_id = ?", [$variantId, $id]
            )->fetch();

            if ($variant) {
                $cartKey = "v_" . $variantId; 
                $price = $variant['price'];
                $image = (!empty($variant['image']) && $variant['image'] != 'default.jpg') ? $variant['image'] : $product['image'];
                $attributes = ($variant['color_name'] ?: "") . ($variant['size_name'] ? " - " . $variant['size_name'] : "");
                
                // Với biến thể, ưu tiên lấy 'stock'
                $stock = $variant['stock'] ?? $variant['quantity'] ?? $stock;
            }
        }

        // Kiểm tra nếu hết hàng (stock <= 0) thì chặn luôn
        if ($stock <= 0) {
            $_SESSION['error'] = "Sản phẩm này tạm thời hết hàng!";
            session_write_close();
            $referer = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/product/index');
            header("Location: " . $referer);
            exit();
        }

        if (!isset($_SESSION['cart'][$cartKey])) {
            $_SESSION['cart'][$cartKey] = [
                'id'         => $id,
                'variant_id' => $variantId,
                'name'       => $name,
                'attributes' => $attributes,
                'price'      => (float)$price,
                'image'      => $image,
                'quantity'   => 1,
                'stock'      => (int)$stock // Lưu trữ stock vào session
            ];
            $_SESSION['success'] = "Đã thêm vào giỏ hàng!";
        } else {
            // Kiểm tra số lượng hiện tại + 1 có vượt quá stock không
            if ($_SESSION['cart'][$cartKey]['quantity'] < $stock) {
                $_SESSION['cart'][$cartKey]['quantity']++;
                $_SESSION['success'] = "Đã cập nhật số lượng!";
            } else {
                $_SESSION['error'] = "Sản phẩm đã đạt giới hạn số lượng trong kho!";
            }
        }

        session_write_close();
        
        $referer = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/product/index');
        header("Location: " . $referer);
        exit();
    }

    public function updateQuantity() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $key = $_POST['id'];
            $quantity = (int)$_POST['quantity'];

            // Lấy giới hạn tồn kho từ session (đã được cập nhật mới nhất từ hàm index)
            $stockLimit = $_SESSION['cart'][$key]['stock'] ?? 0;

            // Kiểm tra: Nếu khách nhập số > kho -> gán bằng kho
            if ($quantity > $stockLimit) {
                $quantity = $stockLimit;
                $_SESSION['error'] = "Số lượng đã được điều chỉnh về mức tối đa ($stockLimit) do hết hàng!";
            }

            if ($quantity > 0) {
                $_SESSION['cart'][$key]['quantity'] = $quantity;
            } else {
                unset($_SESSION['cart'][$key]);
            }
            
            session_write_close();
            $this->redirect('cart/index');
        }
    }

    public function remove($key) {
        if (session_status() === PHP_SESSION_NONE) session_start();
        unset($_SESSION['cart'][$key]);
        session_write_close();
        $this->redirect('cart/index');
    }

    public function clear() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        unset($_SESSION['cart']);
        unset($_SESSION['applied_coupon']);
        session_write_close();
        $this->redirect('cart/index');
    }
}